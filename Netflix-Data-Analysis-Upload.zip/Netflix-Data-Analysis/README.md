# Netflix Data Analysis Project 📊

This project performs data analysis on a Netflix dataset to uncover patterns, trends, and insights about the content available on the platform.

## 📝 Description
This analysis includes:
- Movie vs TV Show distribution
- Country-wise content availability
- Genre-wise content count
- Year-wise release trends
- Actor and director appearance frequency
- Ratings and duration insights

## 🛠️ Technologies Used
- Python
- Pandas
- Matplotlib
- Seaborn
- Jupyter Notebook

## 📸 Sample Visualizations
Bar graphs, heatmaps, pie charts, and line plots are used to visualize the data.

## 🚀 How to Use
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Open `netflix-data-visualization.ipynb` in Jupyter Notebook
4. Run each cell step-by-step

## ✅ Future Enhancements
- Build a recommendation engine
- Add interactive dashboards (with Streamlit/Plotly Dash)

## 🔗 Dataset Source
Dataset from Kaggle: [Netflix Dataset](https://www.kaggle.com/shivamb/netflix-shows)

---
